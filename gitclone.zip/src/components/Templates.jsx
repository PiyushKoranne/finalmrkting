import React from 'react'

const Templates = () => {
  return (
	<div>Templates</div>
  )
}

export default Templates