import React from 'react'

const Audiences = () => {
  return (
	<div className='min-h-screen'>

	</div>
  )
}

export default Audiences